#!/usr/bin/env python3
"""Start an owned CARLA server, wait for RPC readiness, run audits, then stop it."""
import argparse
import datetime
import json
import os
from pathlib import Path
import shutil
import signal
import socket
import subprocess
import sys
import time


def wait_until_ready(client,process,timeout,interval=2.,now=None,sleep=None):
    now=now or time.monotonic;sleep=sleep or time.sleep
    start=now();deadline=start+timeout;next_message=start;last='no response'
    while now()<deadline:
        if process is not None and process.poll() is not None:
            raise RuntimeError('Owned CARLA exited with code %s; inspect server.log' % process.returncode)
        try:
            server=client.get_server_version()
            world=client.get_world()
            return {'server_version':server,'client_version':client.get_client_version(),
                    'map_name':world.get_map().name,'startup_wait_seconds':now()-start}
        except Exception as exc:
            last='%s: %s' % (type(exc).__name__,exc)
        if now()>=next_message:
            print('Waiting for CARLA RPC (%.0fs): %s' % (now()-start,last),flush=True)
            next_message=now()+15.
        remaining=deadline-now()
        if remaining>0:sleep(min(interval,remaining))
    raise TimeoutError('CARLA did not become ready within %.0fs: %s; inspect server.log' % (timeout,last))


def stop_owned_server(process):
    if process is None or process.poll() is not None:return
    # start_new_session=True makes this group exclusively ours. Never search
    # for or terminate other CARLA servers by executable name or port.
    try:os.killpg(process.pid,signal.SIGTERM)
    except ProcessLookupError:return
    try:process.wait(timeout=15.)
    except subprocess.TimeoutExpired:
        try:os.killpg(process.pid,signal.SIGKILL)
        except ProcessLookupError:pass
        process.wait(timeout=15.)


def run_logged(command,path,cwd):
    with path.open('w',encoding='utf-8') as log:
        log.write(json.dumps(command)+'\n');log.flush()
        process=subprocess.Popen(command,cwd=str(cwd),stdout=subprocess.PIPE,stderr=subprocess.STDOUT,
                                 text=True,encoding='utf-8',errors='replace')
        try:
            for line in process.stdout:
                print(line,end='',flush=True);log.write(line);log.flush()
            return process.wait()
        except BaseException:
            if process.poll() is None:
                process.send_signal(signal.SIGINT)
                try:process.wait(timeout=15.)
                except subprocess.TimeoutExpired:process.terminate();process.wait(timeout=15.)
            raise


def main():
    root=Path(__file__).resolve().parent
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--pair-report',type=Path,required=True)
    p.add_argument('--port',type=int,default=31000)
    p.add_argument('--native-records',type=int,default=20)
    p.add_argument('--pool-records',type=int,default=100)
    p.add_argument('--probe-ticks',type=int,default=20)
    p.add_argument('--startup-timeout',type=float,default=600.)
    p.add_argument('--audit-timeout',type=float,default=300.)
    p.add_argument('--output-dir',type=Path)
    p.add_argument('--use-existing-server',action='store_true',help='Only for an already ready, dedicated empty server')
    a=p.parse_args()
    if not a.pair_report.is_file():raise FileNotFoundError(a.pair_report)
    from prepare_hv_diagnostic_subset import validate_subset
    report=json.loads(a.pair_report.read_text(encoding='utf-8'))
    partial=a.pair_report.parent/Path(report['partial_manifest_path']).name
    validate_subset(report,partial.read_bytes())
    if not 0<a.native_records<=a.pool_records or a.probe_ticks<=0 or a.startup_timeout<=0:
        p.error('Require 0 < native-records <= pool-records, probe-ticks/startup-timeout > 0')
    if sys.platform!='linux':raise SystemExit('Managed CARLA launch is for the Linux server; use the existing audit CLI elsewhere')
    carla_root=Path(os.environ.get('CARLA_ROOT') or root/'carla').resolve()
    command=[str(carla_root/'CarlaUE4.sh'),'-nosound','-carla-rpc-port=%d'%a.port,'-nullrhi']
    if not a.use_existing_server:
        if not Path(command[0]).is_file():raise FileNotFoundError(command[0])
        with socket.socket() as check:
            try:check.bind(('127.0.0.1',a.port))
            except OSError as exc:
                raise RuntimeError('Port %d is occupied. Use another free port, or --use-existing-server only '
                                   'if you own that dedicated empty server.' % a.port) from exc
        if os.geteuid()==0:
            runuser=shutil.which('runuser')
            if runuser is None:raise RuntimeError('Root requires runuser -u riftuser to start CARLA')
            command=[runuser,'-u','riftuser','--']+command
    out=a.output_dir or root/'data/hv_init/eval'/('native_managed_'+datetime.datetime.now().strftime('%Y%m%d_%H%M%S_%f'))
    out=out.resolve();out.mkdir(parents=True,exist_ok=False)
    print('RESULT_DIR='+str(out),flush=True)
    status={'server_owned':not a.use_existing_server,'port':a.port,'server_command':command,
            'pair_report':str(a.pair_report.resolve()),'status':'preflight','experiment_exit_code':None}
    (out/'run.json').write_text(json.dumps(vars(a),default=str,indent=2),encoding='utf-8')
    server=None;server_log=None
    try:
        code=run_logged([sys.executable,'-u',str(root/'check_hv_native_environment.py')],out/'preflight.log',root)
        if code:raise RuntimeError('Native dependency preflight failed; inspect preflight.log')
        sys.path.insert(0,str(root/'scenario-dreamer'))
        from high_value_init.carla_audit_environment import configure_carla_pythonapi
        configure_carla_pythonapi(root,validate=True)
        import carla
        if not a.use_existing_server:
            server_log=(out/'server.log').open('w',encoding='utf-8')
            print('Starting owned CARLA:',command,flush=True)
            server=subprocess.Popen(command,cwd=str(carla_root),stdout=server_log,stderr=subprocess.STDOUT,
                                    start_new_session=True)
            status['server_pid']=server.pid
        client=carla.Client('127.0.0.1',a.port);client.set_timeout(5.)
        status['readiness']=wait_until_ready(client,server,a.startup_timeout if server else 5.)
        print('CARLA ready:',json.dumps(status['readiness']),flush=True)
        status['status']='running'
        command=[sys.executable,'-u',str(root/'run_hv_snapshot_diagnostics.py'),
                 '--diagnostic-pair-report',str(a.pair_report),'--with-native','--with-spawn','--with-physics',
                 '--native-records',str(a.native_records),'--max-records',str(a.pool_records),
                 '--probe-ticks',str(a.probe_ticks),'--port',str(a.port),'--timeout',str(a.audit_timeout),
                 '--output-dir',str(out/'experiment')]
        code=run_logged(command,out/'experiment.log',root)
        status['experiment_exit_code']=code;status['status']='completed' if code==0 else 'experiment_failed'
        if code:raise SystemExit(code)
    except BaseException as exc:
        if status['status']=='running':status['status']='experiment_interrupted' if isinstance(exc,KeyboardInterrupt) else 'experiment_failed'
        elif status['status'] not in ('completed','experiment_failed'):status['status']='failed_before_or_during_startup'
        status['error']='%s: %s' % (type(exc).__name__,exc)
        raise
    finally:
        stop_owned_server(server)
        if server_log is not None:server_log.close()
        (out/'status.json').write_text(json.dumps(status,indent=2),encoding='utf-8')
        print('Logs and results:',out,flush=True)


if __name__=='__main__':main()
