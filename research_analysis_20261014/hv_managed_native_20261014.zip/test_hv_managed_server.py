"""Server readiness, owned cleanup and repeated difference-report regression."""
import hashlib
import json
from pathlib import Path
from types import SimpleNamespace
import unittest
from unittest.mock import MagicMock,patch
from run_hv_native_diagnostics import wait_until_ready,stop_owned_server
from diagnose_hv_pair_ambiguity import saved_result


class ManagedReadiness(unittest.TestCase):
    def test_waits_for_rpc_and_world_instead_of_fixed_sleep(self):
        clock=[0.];client=MagicMock()
        client.get_server_version.side_effect=[RuntimeError('not ready'),RuntimeError('not ready'),'0.9.15']
        client.get_client_version.return_value='0.9.15'
        client.get_world.return_value.get_map.return_value.name='Town03'
        process=SimpleNamespace(poll=lambda:None)
        with patch('builtins.print'):
            r=wait_until_ready(client,process,10.,interval=1.,now=lambda:clock[0],
                               sleep=lambda t:clock.__setitem__(0,clock[0]+t))
        self.assertEqual(r['startup_wait_seconds'],2.)
        self.assertEqual(r['map_name'],'Town03')

    def test_dead_server_fails_without_repeated_rpc_wait(self):
        client=MagicMock();process=SimpleNamespace(poll=lambda:1,returncode=1)
        with self.assertRaisesRegex(RuntimeError,'server.log'):
            wait_until_ready(client,process,600.)
        client.get_server_version.assert_not_called()

    def test_unresponsive_server_has_bounded_wait(self):
        clock=[0.];client=MagicMock();client.get_server_version.side_effect=RuntimeError('no RPC')
        with patch('builtins.print'),self.assertRaises(TimeoutError):
            wait_until_ready(client,None,3.,interval=1.,now=lambda:clock[0],
                             sleep=lambda t:clock.__setitem__(0,clock[0]+t))
        self.assertEqual(clock[0],3.)

    def test_cleanup_only_targets_owned_process_group(self):
        process=MagicMock(pid=4321);process.poll.return_value=None
        with patch('run_hv_native_diagnostics.os.killpg',create=True) as kill:
            stop_owned_server(process)
        self.assertEqual(kill.call_args.args[0],4321)
        process.wait.assert_called_once()

    def test_existing_server_is_not_stopped(self):
        with patch('run_hv_native_diagnostics.os.killpg',create=True) as kill:
            stop_owned_server(None)
        kill.assert_not_called()


class CachedDifferences(unittest.TestCase):
    def test_same_report_can_be_read_again_without_overwriting(self):
        data=b'original';value={'source_pair_report_sha256':hashlib.sha256(data).hexdigest(),'records':{}}
        with patch.object(Path,'exists',return_value=True),patch.object(Path,'read_text',return_value=json.dumps(value)), \
                patch.object(Path,'write_text') as write:
            self.assertEqual(saved_result(Path('diff.json'),Path('report.json'),data),value)
        write.assert_not_called()

    def test_changed_source_report_does_not_reuse_stale_result(self):
        value={'source_pair_report_sha256':hashlib.sha256(b'old').hexdigest(),'records':{}}
        with patch.object(Path,'exists',return_value=True),patch.object(Path,'read_text',return_value=json.dumps(value)):
            with self.assertRaisesRegex(FileExistsError,'changed'):
                saved_result(Path('diff.json'),Path('report.json'),b'new')

    def test_legacy_report_without_hash_is_still_readable_at_original_path(self):
        source=Path('report.json');value={'source_pair_report':str(source.resolve()),'records':{}}
        with patch.object(Path,'exists',return_value=True),patch.object(Path,'read_text',return_value=json.dumps(value)):
            self.assertEqual(saved_result(Path('diff.json'),source,b'original'),value)


if __name__=='__main__':unittest.main()
